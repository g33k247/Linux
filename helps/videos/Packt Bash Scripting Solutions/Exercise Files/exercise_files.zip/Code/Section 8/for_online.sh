for i in {1..10}; do echo "Hello World"; done
