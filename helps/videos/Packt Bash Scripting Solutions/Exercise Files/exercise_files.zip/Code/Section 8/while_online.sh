x=10
while [ $x -eq 10 ]; do echo $x; sleep 2; done
