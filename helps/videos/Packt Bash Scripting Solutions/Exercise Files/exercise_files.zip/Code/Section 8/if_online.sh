a=100
if [ $a -eq 100 ]; then echo "a is equal to $a"; fi
