clear
ls -l
date
sudo apt install python3
