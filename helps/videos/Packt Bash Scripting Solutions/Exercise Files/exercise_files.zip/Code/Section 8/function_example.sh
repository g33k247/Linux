#!/bin/bash
print_date()
{
echo "Today is `date`"
return
}
print_date
