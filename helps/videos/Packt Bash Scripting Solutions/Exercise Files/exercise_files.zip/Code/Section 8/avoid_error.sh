echo "Hello World"
a = 100
b=20
c=$((a+b))
echo $a
