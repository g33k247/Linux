#!/bin/bash
echo "Hello World"
a=10
b=20
c=$((a+b))
echo $c
