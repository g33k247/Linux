dialog --stdout --checklist "Enable the account options you want:" 10 40 3 \
              1 "Home directory" on \
              2 "Signature file" off \
              3 "Simple password" off
