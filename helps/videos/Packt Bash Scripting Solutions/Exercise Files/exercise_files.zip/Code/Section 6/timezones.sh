TZ=":Antarctica/Casey" date
TZ=":Atlantic/Bermuda" date
TZ=":Asia/Calcutta" date
TZ=":Europe/Amsterdam" date
