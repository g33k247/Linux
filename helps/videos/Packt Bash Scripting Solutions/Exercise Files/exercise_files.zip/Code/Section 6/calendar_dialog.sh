dialog --calendar "Select a date... " 0 0 1 1 2018
val=$?
