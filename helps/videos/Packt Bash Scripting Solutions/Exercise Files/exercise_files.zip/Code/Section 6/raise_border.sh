convert -raise 5x5 mountain.jpeg mountain-raised.png
