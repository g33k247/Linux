#!/bin/bash
VAR=$0
echo "I was ran as: $VAR"
