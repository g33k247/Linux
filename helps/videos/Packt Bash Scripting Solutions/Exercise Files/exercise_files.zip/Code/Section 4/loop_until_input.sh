#!/bin/bash
EXIT_PLEASE=0
until [ $EXIT_PLEASE != 0 ]
do
   echo "Pres CTRL+C to stop..."
   sleep 1
done
exit 0
