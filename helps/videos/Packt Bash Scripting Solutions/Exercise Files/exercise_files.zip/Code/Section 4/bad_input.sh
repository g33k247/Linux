#!/bin/bash

FILE_NAME=$1
echo $FILE_NAME
ls $FILE_NAME
