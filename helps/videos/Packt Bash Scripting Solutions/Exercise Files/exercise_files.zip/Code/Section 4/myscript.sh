#!/bin/bash

for (( ; ; ))
do
   sleep 1
done
