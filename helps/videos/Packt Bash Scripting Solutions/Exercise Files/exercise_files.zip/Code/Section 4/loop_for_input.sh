#!/bin/bash
for (( ; ; ))
do
   echo "Shall run for ever"
   sleep 1
done
exit 0
