#!/bin/bash

VAR=10


if [ $VAR -eq 1 ]; then
    echo "$VAR"
elif [ $VAR -eq 2 ]; then
    echo "$VAR"
elif [ $VAR -eq 3 ]; then
    echo "$VAR"
elif [ $VAR -eq 4 ]; then
    echo "$VAR"
elif [ $VAR -eq 5 ]; then
    echo "$VAR"
elif [ $VAR -eq 6 ]; then
    echo "$VAR"
elif [ $VAR -eq 7 ]; then
    echo "$VAR"
elif [ $VAR -eq 8 ]; then
    echo "$VAR"
elif [ $VAR -eq 9 ]; then
    echo "$VAR"
elif [ $VAR -eq 10 ]; then
    echo "$VAR"
else
    echo "I am not looking to match this value"
fi
