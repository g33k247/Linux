#!/bin/bash

whoami
pwd
ls
echo “Echo one 1”; echo “Echo two 2”
